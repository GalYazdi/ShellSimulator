#!/bin/bash
gcc -Wall ex2.c -o ex2
./ex2
